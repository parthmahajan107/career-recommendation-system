# CAREER GUIDANCE SYSTEM


created by B15 group of B.Tech CSE Div:B